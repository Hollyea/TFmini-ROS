#include <TFluna.h>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "tfluna_ros_node");
  ros::NodeHandle nh("~");
  std::string id = "TFluna";
  std::string portName;
  int baud_rate;
  benewake::TFluna *tfluna_obj;

  nh.param("serial_port", portName, std::string("/dev/ttyUSB0"));
  nh.param("baud_rate", baud_rate, 115200);

  tfluna_obj = new benewake::TFluna(portName, baud_rate);
  ros::Publisher pub_range = nh.advertise<sensor_msgs::Range>(id, 1000, true);
  sensor_msgs::Range TFluna_range;
  TFluna_range.radiation_type = sensor_msgs::Range::INFRARED;
  TFluna_range.field_of_view = 0.0349066; # In degrees it is 2 is it's converted into radians.
  TFluna_range.min_range = 0.2;
  TFluna_range.max_range = 8;
  TFluna_range.header.frame_id = id;
  float dist = 0;
  ROS_INFO_STREAM("Start processing ...");

  while(ros::master::check() && ros::ok())
  {
    ros::spinOnce();
    dist = tfluna_obj->getDist();
    if(dist > 0 && dist < TFluna_range.max_range)
    {
      TFluna_range.range = dist;
      TFluna_range.header.stamp = ros::Time::now();
      pub_range.publish(TFluna_range);
    }
    else if(dist == -1.0)
    {
      ROS_ERROR_STREAM("Failed to read data. TFluna ros node stopped!");
      break;
    }
    else if(dist == 0.0)
    {
      ROS_ERROR_STREAM("Data validation error!");
    }
  }

  tfluna_obj->closePort();
}
