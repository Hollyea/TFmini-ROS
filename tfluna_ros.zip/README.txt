/**************************************************************************************************************************************
/* Benewake TFluna infrared range sensor TFluna ROS package
/* Version 1.0
/**************************************************************************************************************************************

/**************************************************************************************************************************************
/* Package Information
/**************************************************************************************************************************************
  Package:			tfluna_ros
  Node:				tfluna_ros_node
  Published Topics:
    /tfluna_ros_node/TFluna (sensor_msgs/Range)
      The distance of object detected. 
      Note: This node won't publish topic if no object exists within TFluna's measurement range, and the behavior can be changed in file 
      /src/TFluna_ros_node.cpp
      
/**************************************************************************************************************************************
/* Quick Start
/**************************************************************************************************************************************
  $ cd tfluna_ros/src
  $ catkin_make
  $ roslaunch tfluna_ros tfluna.launch
